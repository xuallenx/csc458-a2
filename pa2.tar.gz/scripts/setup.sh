#!/bin/bash

sudo pip3 install termcolor matplotlib numpy
